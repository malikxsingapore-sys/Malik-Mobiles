const products=[
{name:"iPhone 17",series:"17",price:399999,desc:"Next-generation iPhone"},
{name:"iPhone 17 Pro",series:"17",price:499999,desc:"Pro performance"},
{name:"iPhone 17 Pro Max",series:"17",price:549999,desc:"Maximum power"},
{name:"iPhone Air",series:"17",price:449999,desc:"Light and powerful"},
{name:"iPhone 16",series:"16",price:329999,desc:"Powerful everyday iPhone"},
{name:"iPhone 16 Pro",series:"16",price:429999,desc:"Pro camera and performance"},
{name:"iPhone 16 Pro Max",series:"16",price:479999,desc:"Large Pro experience"},
{name:"iPhone 15",series:"15",price:279999,desc:"Great all-round iPhone"},
{name:"iPhone 15 Pro",series:"15",price:359999,desc:"Titanium Pro design"}
];
let filter="all",cart=[];
function money(n){return "PKR "+n.toLocaleString()}
function renderProducts(){
 const q=document.getElementById("search").value.toLowerCase();
 const list=products.filter(p=>(filter==="all"||p.series===filter)&&p.name.toLowerCase().includes(q));
 document.getElementById("productGrid").innerHTML=list.map((p,i)=>`
 <article class="card">
  <div class="phone-img"><br>${p.name.replace("iPhone ","")}</div>
  <h3>${p.name}</h3><p>${p.desc}</p><div class="price">${money(p.price)}</div>
  <button onclick="addToCart(${products.indexOf(p)})">Add to Cart</button>
 </article>`).join("");
}
function setFilter(f,el){filter=f;document.querySelectorAll(".filters button").forEach(b=>b.classList.remove("active"));el.classList.add("active");renderProducts()}
function addToCart(i){cart.push(products[i]);document.getElementById("cartCount").textContent=cart.length;showCart()}
function showCart(){
 document.getElementById("modalTitle").textContent="Your Cart";
 const body=document.getElementById("modalBody");
 if(!cart.length){body.innerHTML="<p>Your cart is empty.</p>";}
 else{
  const total=cart.reduce((a,p)=>a+p.price,0);
  body.innerHTML=cart.map((p,i)=>`<div class="cart-item"><span>${p.name}</span><b>${money(p.price)}</b></div>`).join("")+
  `<h3>Total: ${money(total)}</h3><button class="checkout" onclick="orderWhatsApp()">Order on WhatsApp</button>`;
 }
 document.getElementById("modal").classList.remove("hidden");
}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
function orderWhatsApp(){
 const text="Assalam o Alaikum, I want to order:%0A"+cart.map(p=>"- "+p.name+" ("+money(p.price)+")").join("%0A");
 window.open("https://wa.me/923000000000?text="+text,"_blank");
}
renderProducts();